/*14. Eliminar duplicados:
Escribir un programa que elimine los elementos duplicados de una lista.*/
public class ejercicio_14 {
    public static void main(String[] args){
        try{
            int list=[];

        } catch (Exception e) {
            System.out.println("Uy parce hiciste algo mal");
        }
    }
}
